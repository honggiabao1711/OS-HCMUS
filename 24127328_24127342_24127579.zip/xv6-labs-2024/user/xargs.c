#include "kernel/types.h"
#include "kernel/stat.h"
#include "kernel/param.h"
#include "user/user.h"

int main(int argc, char *argv[]) {
    char buf[512], *args[MAXARG];
    int i, arg_start = 1;

    // parse -n 1
    if (argc >= 3 && strcmp(argv[1], "-n") == 0 && strcmp(argv[2], "1") == 0)
        arg_start = 3;

    if (argc - arg_start < 1) {
        fprintf(2, "Usage: xargs [-n 1] command [args...]\n");
        exit(1);
    }

    for (i = arg_start; i < argc; i++)
        args[i - arg_start] = argv[i];

    while (1) {
        int n = 0, r;
        char c;

        while ((r = read(0, &c, 1)) == 1 && c != '\n')
            if (n < sizeof(buf) - 1) buf[n++] = c;

        if (r == 0 && n == 0) break;

        buf[n] = 0;
        args[argc - arg_start] = buf;
        args[argc - arg_start + 1] = 0;

        int pid = fork();
        if (pid < 0) exit(1);
        if (pid == 0) {
            exec(args[0], args);
            fprintf(2, "exec failed\n");
            exit(1);
        } else wait(0);
    }
    exit(0);
}